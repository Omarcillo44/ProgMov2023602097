package com.prueba.conexion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConexionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConexionApplication.class, args);
	}

}
