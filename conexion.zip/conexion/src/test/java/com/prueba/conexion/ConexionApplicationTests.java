package com.prueba.conexion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConexionApplicationTests {

	@Test
	void contextLoads() {
	}

}
